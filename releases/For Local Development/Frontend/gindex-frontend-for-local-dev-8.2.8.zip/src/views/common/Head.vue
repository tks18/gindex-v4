<template>
  <div>
    <Navbar ref="navbar"></Navbar>
  </div>
</template>

<script>
import Navbar from "./Navbar";

export default {
  data: function() {
    return {};
  },
  methods: {},
  components: {
    Navbar
  }
};
</script>
